import json
import os
import pandas as pd
import matplotlib.pyplot as plt
import re
import seaborn as sns  

plt.rcParams['font.sans-serif'] = ['SimHei']  # 指定中文字体
plt.rcParams['axes.unicode_minus'] = False    # 正常显示负号

# 定义城市对应关系
cities = {
    'bj': '北京',
    'sh': '上海',
    'gz': '广州',
    'sz': '深圳',
    'changde': '常德'
}

data = {city: [] for city in cities.values()}

# 正则表达式提取首个数字
rooms_pattern = re.compile(r'(\d+)')

for folder, city in cities.items():
    file_path = os.path.join(folder, 'zufang.json')
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                try:
                    listing = json.loads(line)
                    
                    # 提取并处理各字段
                    name = listing.get('name', '').strip()
                    region = listing.get('region', '').strip()
                    block = listing.get('block', '').strip()
                    street = listing.get('street', '').strip()
                    orientation = listing.get('orientation', '').strip()
                    
                    # 处理 rooms 字段
                    rooms_match = rooms_pattern.search(listing.get('rooms', ''))
                    if rooms_match:
                        rooms = int(rooms_match.group(1))
                    else:
                        continue  # 无法提取房间数，跳过该条目
                    
                    # 处理 rent 字段
                    rent_original = listing.get('rent', '').strip()
                    if '未知' in rent_original:
                        continue  # 租金未知，跳过该条目
                    rent_str = rent_original.replace('元/月', '').strip()
                    if '-' in rent_str:
                        min_rent, max_rent = rent_str.split('-', 1)
                        rent = (int(min_rent) + int(max_rent)) / 2
                    else:
                        rent = int(rent_str)
                    
                    # 处理 area 字段
                    area_str = listing.get('area', '').replace('㎡', '').strip()
                    if '-' in area_str:
                        min_area, max_area = area_str.split('-', 1)
                        area = (float(min_area) + float(max_area)) / 2
                    else:
                        area = float(area_str)
                    
                    rent_per_sqm = rent / area if area else 0
                    
                    # 添加到对应城市的 data 中
                    data[city].append({
                        '名称': name,
                        '区域': region,
                        '板块': block,
                        '街道': street,
                        '朝向': orientation,
                        '房间数': rooms,
                        '租金': rent,
                        '面积': area,
                        '单位面积租金': rent_per_sqm
                    })
                except (ValueError, KeyError, AttributeError):
                    continue  # 转换失败，删除该条目

# 将所有城市的数据合并为一个列表用于分析
combined_data = []
for city, listings in data.items():
    for listing in listings:
        combined_listing = {'城市': city}
        combined_listing.update(listing)
        combined_data.append(combined_listing)

df = pd.DataFrame(combined_data)

# 处理多朝向数据
df['朝向'] = df['朝向'].str.split()  # 将朝向字符串拆分为列表
df_exploded = df.explode('朝向')      # 展开为多行，每行一个朝向

# 检查是否有数据
if df_exploded.empty:
    print("没有有效的数据可供分析。")
    exit()

# 定义有效朝向
valid_orientations = ['东', '南', '西', '北', '东南', '东北', '西南', '西北']

# 过滤出有效朝向
orientation_filtered_df = df_exploded[df_exploded['朝向'].isin(valid_orientations)]

# 计算总体统计信息并保存到1.csv
stats = df.groupby('城市').agg(
    租金均价=('租金', 'mean'),
    租金最高价=('租金', 'max'),
    租金最低价=('租金', 'min'),
    租金中位数=('租金', 'median'),
    单位面积租金均价=('单位面积租金', 'mean'),
    单位面积租金最高价=('单位面积租金', 'max'),
    单位面积租金最低价=('单位面积租金', 'min'),
    单位面积租金中位数=('单位面积租金', 'median')
).reset_index()

print(stats)
stats.to_csv('1.csv', index=False)

# 计算按房间数（1居、2居、3居）统计信息并保存到2.csv

# 过滤出房间数为1, 2, 3的记录
filtered_df = df[df['房间数'].isin([1, 2, 3])]

# 计算统计信息
room_stats = filtered_df.groupby(['城市', '房间数']).agg(
    租金均价=('租金', 'mean'),
    租金最高价=('租金', 'max'),
    租金最低价=('租金', 'min'),
    租金中位数=('租金', 'median'),
    单位面积租金均价=('单位面积租金', 'mean'),
    单位面积租金最高价=('单位面积租金', 'max'),
    单位面积租金最低价=('单位面积租金', 'min'),
    单位面积租金中位数=('单位面积租金', 'median')
).reset_index()

print(room_stats)
room_stats.to_csv('2.csv', index=False)

# 计算并分析每个城市不同板块的均价情况，并保存到3.csv

# 过滤出板块非空的记录
block_filtered_df = df[df['板块'] != '']

# 计算统计信息
block_stats = block_filtered_df.groupby(['城市', '板块']).agg(
    租金均价=('租金', 'mean'),
    租金最高价=('租金', 'max'),
    租金最低价=('租金', 'min'),
    租金中位数=('租金', 'median'),
    单位面积租金均价=('单位面积租金', 'mean'),
    单位面积租金最高价=('单位面积租金', 'max'),
    单位面积租金最低价=('单位面积租金', 'min'),
    单位面积租金中位数=('单位面积租金', 'median')
).reset_index()

print(block_stats)
block_stats.to_csv('3.csv', index=False)

# 计算并分析每个城市不同朝向的单位面积租金分布情况，并保存到4.csv

# 计算统计信息
orientation_stats = orientation_filtered_df.groupby(['城市', '朝向']).agg(
    单位面积租金均价=('单位面积租金', 'mean'),
    单位面积租金最大值=('单位面积租金', 'max'),
    单位面积租金最小值=('单位面积租金', 'min'),
    单位面积租金中位数=('单位面积租金', 'median')
).reset_index()

print(orientation_stats)
orientation_stats.to_csv('4.csv', index=False)

# 定义各城市人均GDP
gdp_data = {
    '北京': 200370,
    '上海': 190783,
    '广州': 162070,
    '深圳': 195959,
    '常德': 84189
}

# 将人均GDP添加到stats DataFrame
stats['人均GDP'] = stats['城市'].map(gdp_data)

# 保存GDP数据到5.csv
gdp_df = pd.DataFrame(list(gdp_data.items()), columns=['城市', '人均GDP'])
gdp_df.to_csv('5.csv', index=False)

# 计算GDP与单位面积租金均价的关系
gdp_rent_corr = stats[['人均GDP', '单位面积租金均价']].corr()
print("人均GDP与单位面积租金均价的相关性：")
print(gdp_rent_corr)

# 保存相关性结果到6.csv
gdp_rent_corr.to_csv('6.csv')

# 定义各城市平均工资
average_salary_data = {
    '北京': 15701,
    '上海': 12307,
    '广州': 13193,
    '深圳': 14553,
    '常德': 5528
}

# 将平均工资添加到stats DataFrame
stats['平均工资'] = stats['城市'].map(average_salary_data)

# 保存平均工资数据到7.csv
salary_df = pd.DataFrame(list(average_salary_data.items()), columns=['城市', '平均工资'])
salary_df.to_csv('7.csv', index=False)

# 计算平均工资与单位面积租金均价的关系
salary_rent_corr = stats[['平均工资', '单位面积租金均价']].corr()
print("平均工资与单位面积租金均价的相关性：")
print(salary_rent_corr)

# 保存相关性结果到8.csv
salary_rent_corr.to_csv('8.csv')

# 可视化GDP与单位面积租金均价的关系
plt.figure(figsize=(8,6))
sns.scatterplot(data=stats, x='人均GDP', y='单位面积租金均价', hue='城市', s=100)
sns.regplot(data=stats, x='人均GDP', y='单位面积租金均价', scatter=False, color='blue')
for i in range(stats.shape[0]):
    plt.text(stats['人均GDP'][i]+1000, stats['单位面积租金均价'][i]+0.1, stats['城市'][i])
plt.title('人均GDP与单位面积租金均价关系')
plt.xlabel('人均GDP (元)')
plt.ylabel('单位面积租金均价 (元/平米)')
plt.savefig('人均GDP与单位面积租金均价关系.png')
plt.tight_layout()
plt.show()

# 可视化平均工资与单位面积租金均价的关系
plt.figure(figsize=(8,6))
sns.scatterplot(data=stats, x='平均工资', y='单位面积租金均价', hue='城市', s=100)
sns.regplot(data=stats, x='平均工资', y='单位面积租金均价', scatter=False, color='green')
for i in range(stats.shape[0]):
    plt.text(stats['平均工资'][i]+100, stats['单位面积租金均价'][i]+0.1, stats['城市'][i])
plt.title('平均工资与单位面积租金均价关系')
plt.xlabel('平均工资 (元/月)')
plt.ylabel('单位面积租金均价 (元/平米)')
plt.savefig('平均工资与单位面积租金均价关系.png')
plt.tight_layout()
plt.show()

# 可视化总体租金均价
plt.figure(figsize=(10,6))
plt.bar(stats['城市'], stats['租金均价'], color='skyblue')
plt.title('五个城市租金均价对比')
plt.xlabel('城市')
plt.ylabel('租金均价 (元/月)')
plt.savefig('租金均价对比.png')
plt.show()

# 可视化单位面积租金均价
plt.figure(figsize=(10,6))
plt.bar(stats['城市'], stats['单位面积租金均价'], color='salmon')
plt.title('五个城市单位面积租金均价对比')
plt.xlabel('城市')
plt.ylabel('单位面积租金均价 (元/平米)')
plt.savefig('单位面积租金均价对比.png')
plt.show()

# 可视化按房间数的租金均价
plt.figure(figsize=(12,8))
sns.barplot(data=room_stats, x='城市', y='租金均价', hue='房间数')
plt.title('五个城市不同居室数租金均价对比')
plt.xlabel('城市')
plt.ylabel('租金均价 (元/月)')
plt.legend(title='房间数')
plt.savefig('不同居室数租金均价对比.png')
plt.show()

# 可视化按房间数的单位面积租金均价
plt.figure(figsize=(12,8))
sns.barplot(data=room_stats, x='城市', y='单位面积租金均价', hue='房间数')
plt.title('五个城市不同居室数单位面积租金均价对比')
plt.xlabel('城市')
plt.ylabel('单位面积租金均价 (元/平米)')
plt.legend(title='房间数')
plt.savefig('不同居室数单位面积租金均价对比.png')
plt.show()

# 可视化每个城市不同板块的租金均价
# 选择每个城市前5个板块
for city in cities.values():
    city_block_stats = block_stats[block_stats['城市'] == city].nlargest(5, '租金均价')  # 取租金均价最高的前5个板块
    plt.figure(figsize=(10,6))
    sns.barplot(data=city_block_stats, x='租金均价', y='板块', palette='viridis')
    plt.title(f'{city} 不同板块租金均价对比')
    plt.xlabel('租金均价 (元/月)')
    plt.ylabel('板块')
    plt.tight_layout()
    plt.savefig(f'{city}_板块租金均价对比.png')
    plt.show()

# 可视化每个城市不同朝向的单位面积租金分布
for city in cities.values():
    city_orientation_stats = orientation_stats[orientation_stats['城市'] == city]
    plt.figure(figsize=(10,6))
    sns.barplot(data=city_orientation_stats, x='朝向', y='单位面积租金均价', palette='magma')
    plt.title(f'{city} 不同朝向单位面积租金均价对比')
    plt.xlabel('朝向')
    plt.ylabel('单位面积租金均价 (元/平米)')
    plt.tight_layout()
    plt.savefig(f'{city}_朝向单位面积租金均价对比.png')
    plt.show()