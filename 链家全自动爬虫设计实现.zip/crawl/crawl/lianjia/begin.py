import os
import sys
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from scrapy import signals
from lianjia.spiders.split_spider import SplitSpider
from lianjia.spiders.zufang_spider import ZufangSpider
from scrapy.signalmanager import dispatcher
from proxy import update_ip

os.environ.setdefault('SCRAPY_SETTINGS_MODULE', 'lianjia.settings')

def run_spider():
    process = CrawlerProcess(get_project_settings())   
    status_code = 0

    def handle_spider_closed(spider, reason):
        nonlocal status_code
        if reason != 'finished':
            status_code = 1
    
    dispatcher.connect(handle_spider_closed, signal=signals.spider_closed)
    
    # process.crawl(SplitSpider)

    update_ip()
    process.crawl(ZufangSpider)
    process.start()

    sys.exit(status_code)

if __name__ == '__main__':
    run_spider()
