import requests

api_url = 'https://sch.shanchendaili.com/api.html?action=get_ip&key=HUf4a10641508086008601B6&time=10&count=1&type=text&textSep=1&province=215&city=215&only=1'  
# PROXY_USER = '81AF4B34'  
# PROXY_PASS = '6EDC31393909'  

def update_ip():
    response = requests.get(api_url)
    if response.status_code == 200:
        proxy = response.text.strip()
        with open('ip.txt', 'w') as file:
            file.write(proxy)

def get_proxy():
    with open('ip.txt', 'r') as file:
        return file.read().strip()

def get_proxy_url():
    proxy = get_proxy()
    # return f"http://{PROXY_USER}:{PROXY_PASS}@{proxy}"
    return f"http://{proxy}"