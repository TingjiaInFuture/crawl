import subprocess
import time

def run():
    while True:
        process = subprocess.Popen(['python', 'begin.py'])
        process.wait()
        print(process.returncode)
        if process.returncode != 0:
            print("正在重新启动...")
            time.sleep(1)
        else:
            break

if __name__ == "__main__":
    run()