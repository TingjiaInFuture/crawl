import scrapy

class ZufangItem(scrapy.Item):
    name = scrapy.Field()
    region = scrapy.Field()
    block = scrapy.Field()
    street = scrapy.Field()
    rent = scrapy.Field()
    area = scrapy.Field()
    orientation = scrapy.Field()
    rooms = scrapy.Field()