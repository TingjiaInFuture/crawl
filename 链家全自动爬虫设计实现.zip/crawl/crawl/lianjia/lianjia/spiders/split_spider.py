import scrapy
import json
ljurl = 'changde.lianjia.com'
class SplitSpider(scrapy.Spider):
    name = "split"
    allowed_domains = [f"{ljurl}"]
    start_min = 150     #不同城市的价格范围不同，需要修改！！！
    start_max = 55000
    max_total = 3000

    custom_settings = {
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0',
        'DEFAULT_REQUEST_HEADERS': {
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
            'Cookie': 'lianjia_ssid=801a9f7d-1067-4230-a958-ae30aee9e0ca;'
        },
        'COOKIES_ENABLED': True,
        'ROBOTSTXT_OBEY': False,
    }

    def start_requests(self):
        yield scrapy.Request(
            url=f"https://{ljurl}/zufang/brp{self.start_min}erp{self.start_max}/",
            callback=self.parse,
            meta={'min': self.start_min, 'max': self.start_max}
        )

    def parse(self, response):
        total = int(response.xpath('/html/body/div[3]/div[1]/div[5]/div[1]/p/span[1]/text()').get(default='0').strip())
        min_price = response.meta['min']
        max_price = response.meta['max']

        if total > self.max_total:
            mid = (min_price + max_price) // 2
            if min_price >= mid or mid == max_price:
                if total < 4000: #可以容忍的近似处理
                   with open('slices.json', 'a', encoding='utf-8') as f:
                        json.dump({'min': min_price, 'max': max_price, 'total': 3000}, f, ensure_ascii=False)
                        f.write('\n')
                else:
                    raise ValueError(f"无法进一步分割区间: ({min_price}, {max_price})，总数: {total}")
                self.logger.info(f"无法进一步分割区间: ({min_price}, {max_price})，总数: {total}")
                return
            yield scrapy.Request(
                url=f"https://{ljurl}/zufang/brp{min_price}erp{mid}/",
                callback=self.parse,
                meta={'min': min_price, 'max': mid}
            )
            yield scrapy.Request(
                url=f"https://{ljurl}/zufang/brp{mid+1}erp{max_price}/",
                callback=self.parse,
                meta={'min': mid+1, 'max': max_price}
            )
        else:
            self.logger.info(f"区间 ({min_price}, {max_price}) 的总数为 {total}")
            with open('slices.json', 'a', encoding='utf-8') as f:
                json.dump({'min': min_price, 'max': max_price, 'total': total}, f, ensure_ascii=False)
                f.write('\n')