import scrapy
import json
import re
from lianjia.items import ZufangItem
from scrapy.exceptions import CloseSpider
ljurl = 'changde.lianjia.com'
class ZufangSpider(scrapy.Spider):
    name = "zufang"
    allowed_domains = [f"{ljurl}"]
    flag = 0 
    pg = 0 
    brp = 0 
    erp = 0 
    start_urls = []

    def __init__(self, *args, **kwargs):
        super(ZufangSpider, self).__init__(*args, **kwargs)
        self.update_urls()

    def update_urls(self):
        ## 根据日志文件实现断点续传
        with open('log.json', 'r', encoding='utf-8') as f:
            lines = f.readlines()
            if lines:
                last_line = lines[-1]
                entry = json.loads(last_line)
                url = entry['url']
                match = re.search(r'pg(\d+)brp(\d+)erp(\d+)/', url)
                if match:
                    self.pg, self.brp, self.erp = map(int, match.groups())
                    self.flag = 1

        with open('slices.json', 'r', encoding='utf-8') as f:
            for line in f:
                entry = json.loads(line)
                min_val = entry['min']
                max_val = entry['max']
                total = entry['total']
                pages = total // 30 + 1
                if self.flag == 1: #首先断点续传，保证按划分顺序爬取
                    if min_val == self.brp:
                        self.flag = 0                        
                        for i in range(self.pg+1, pages + 1):
                            url = f"https://{ljurl}/zufang/pg{i}brp{self.brp}erp{max_val}/"
                            self.start_urls.append(url)
                    continue
                for i in range(1, pages + 1):
                    url = f"https://{ljurl}/zufang/pg{i}brp{min_val}erp{max_val}/"
                    self.start_urls.append(url)


    custom_settings = {
        'ITEM_PIPELINES': {'lianjia.pipelines.ZufangPipeline': 500},
        'DEFAULT_REQUEST_HEADERS': {
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
            'Cookie': 'lianjia_uuid=8f18da19-3fdc-4353-8c28-49de2e078a9b; expires=Sun, 24-Dec-34 12:05:48 GMT; Max-Age=315360000; domain=.lianjia.com; path=/'
        },
        'COOKIES_ENABLED': True,
    }

    def parse(self, response):
        if "captcha" in response.url:
            self.logger.info(f"验证码页面检测到: {response.url}")
            raise CloseSpider('captcha_detected')  
            # process.stop()  
            # update_ip()
            # process.crawl(ZufangSpider)  
            # process.start()  
            # return
        
        items_count = 0
        for sel in response.xpath('/html/body/div[3]/div[1]/div[5]/div[1]/div[1]//div[@class="content__list--item--main"]'):
            item = ZufangItem()
            
            # 提取整租名称
            title = sel.xpath('.//p[@class="content__list--item--title"]/a/text()').get()
            if title:
                name = title.split()[0]
                item['name'] = name.strip()
            else:
                item['name'] = ''
            
            # 提取独栋名称
            title = sel.xpath('.//p[@class="content__list--item--title twoline"]/a/text()').get()
            if title:
                name = title.split()[0]
                item['name'] = name.strip()

            # 提取区域、板块、街道
            item['region'] = sel.xpath('.//p[@class="content__list--item--des"]/a[1]/text()').get(default='').strip()
            item['block'] = sel.xpath('.//p[@class="content__list--item--des"]/a[2]/text()').get(default='').strip()
            item['street'] = sel.xpath('.//p[@class="content__list--item--des"]/a[3]/text()').get(default='').strip()

            # 提取面积、朝向、居室
            h = 0
            is_featured = sel.xpath('.//p[@class="content__list--item--des"]/text()[1]').get()
            if '精选' in is_featured.strip():
                 h = 1
            des_p = sel.xpath('.//p[@class="content__list--item--des"]')
            item['area'] = des_p.xpath(f'normalize-space(.//i[{h+1}]/following-sibling::text()[1])').get(default='/').strip()
            item['rooms'] = des_p.xpath(f'normalize-space(.//i[{h+3}]/following-sibling::text()[1])').get(default='/').strip()
            if "独栋" in item['name']:
                    item['orientation'] = ''
            else:
                item['orientation'] = des_p.xpath(f'normalize-space(.//i[{h+2}]/following-sibling::text()[1])').get(default='/').strip()
 
            # 提取租金
            item['rent'] = sel.xpath('.//span[@class="content__list--item-price"]/em/text()').get(default='/').strip() + '元/月'
            items_count += 1
            yield item

        log_entry = {
            "url": response.url,
            "items_count": items_count
        }

        with open('log.json', 'a', encoding='utf-8') as log_file:
            log_file.write(json.dumps(log_entry, ensure_ascii=False) + '\n')